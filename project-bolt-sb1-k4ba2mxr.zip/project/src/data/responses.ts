import { FinancialTopic } from '../types';

export const financialTopics: FinancialTopic[] = [
  {
    keywords: ['save', 'saving', 'savings', 'emergency fund'],
    response: "It's recommended to save 20% of your income and maintain an emergency fund covering 3-6 months of expenses. Start small if needed - even $50 per month helps build the habit."
  },
  {
    keywords: ['invest', 'investing', 'investment', 'stock', 'stocks'],
    response: "For long-term investing, consider low-cost index funds. They offer broad market exposure and historically provide good returns. Remember to diversify your portfolio and only invest what you can afford to lose."
  },
  {
    keywords: ['budget', 'budgeting', 'spending'],
    response: "Try the 50/30/20 rule: 50% for needs, 30% for wants, and 20% for savings and debt repayment. Track your spending for a month to understand your habits."
  },
  {
    keywords: ['debt', 'loan', 'credit'],
    response: "Prioritize paying off high-interest debt first, like credit cards. Consider the debt avalanche method: pay minimums on all debts, then put extra money toward the highest-interest debt."
  },
  {
    keywords: ['retirement', '401k', 'ira'],
    response: "Start saving for retirement as early as possible. If your employer offers a 401(k) match, try to contribute enough to get the full match - it's essentially free money."
  }
];